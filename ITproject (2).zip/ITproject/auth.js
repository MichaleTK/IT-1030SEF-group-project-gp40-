let users = JSON.parse(localStorage.getItem("users")) || [];

// Toggle between Login and Registration Forms
function toggleAuthForm(formType) {
  const loginForm = document.getElementById("login-form");
  const regForm = document.getElementById("registration-form");

  if (formType === "login") {
    loginForm.style.display = "block";
    regForm.style.display = "none";
  } else {
    loginForm.style.display = "none";
    regForm.style.display = "block";
  }
}

// Register a New User
function register() {
  const username = document.getElementById("reg-username").value;
  const password = document.getElementById("reg-password").value;

  if (username && password) {
    const userExists = users.some(user => user.username === username);
    if (userExists) {
      alert("Username already exists. Please choose another.");
    } else {
      users.push({ username, password });
      localStorage.setItem("users", JSON.stringify(users));
      alert("Registration successful! Please login.");
      toggleAuthForm("login");
    }
  } else {
    alert("Please fill in all fields.");
  }
}

// Login
function login() {
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;

  const user = users.find(user => user.username === username && user.password === password);
  if (user) {
    localStorage.setItem("currentUser", username);
    
    // Notify the parent window if exists
    if (window.opener && !window.opener.closed) {
      window.opener.postMessage({ type: 'login', username: username }, '*');
      window.close();
    } else {
      // If opened directly, redirect to index.html
      window.location.href = "index.html";
    }
  } else {
    alert("Invalid username or password.");
  }
}