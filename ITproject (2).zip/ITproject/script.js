// User System
let users = JSON.parse(localStorage.getItem("users")) || [];
let currentUser = localStorage.getItem("currentUser") || null;

// Product Data
const products = [
  {
    id: 1,
    name: "Apple(dozen)",
    category: "food",
    price: 20,
    image: "apple.jpg",
    description: "Fresh organic apples from local farms",
    reviews: [
      { user: "John", rating: 5, comment: "Perfect for snacks!" },
      { user: "Sarah", rating: 4, comment: "Good quality" }
    ]
  },
  {
    id: 2,
    name: "Toothpaste(single)",
    category: "healthcare",
    price: 12,
    image: "toothpaste.jpg",
    description: "Mint flavor with fluoride protection",
    reviews: [
      { user: "Mike", rating: 5, comment: "Leaves mouth fresh" }
    ]
  },
  {
    id: 3,
    name: "Phone",
    category: "electronics",
    price: 3000,
    image: "https://1.bp.blogspot.com/-4G4O6tg72hU/V72PckDyvxI/AAAAAAAAATA/lrLq30O0VzEIy_3JHw0FVFeC7v9a7QzVwCEw/s1600/mobile8.png",
    description: "Fresh organic apples from local farms",
    reviews: [
      { user: "John", rating: 3, comment: "works fine" },
      { user: "Eric", rating: 4, comment: "Good quality" }
    ]
  },
  
  {
    id: 4,
    name: "Shoes",
    category: "clothes",
    price: 276,
    image: "https://i.pinimg.com/736x/25/c0/63/25c06348fbc24ba99d45077fc307829e.jpg",
    description: "shoes for casual wear",
    reviews: [
      { user: "Tim", rating: 4, comment: "good for daily use" },
      { user: "Eric", rating: 3, comment: "Good quality" }
    ]
  },

  {
    id: 5,
    name: "Apple juice(bottle)",
    category: "food",
    price: 10,
    image: "https://www.organicorigins.com.au/cdn/shop/products/apple-juice_600x.jpg?v=1632630093",
    description: "Fresh organic apples juice directly from farm ",
    reviews: [
      { user: "John", rating: 2, comment: "It is too easy to be expired" },
      { user: "Eric", rating: 4, comment: "Good quality" }
    ]
  },

  {
    id: 6,
    name: "Laptop",
    category: "electronics",
    price: 6000,
    image: "https://th.bing.com/th/id/OIP.ecPUvX9aHRgM9NvCNyhpAwHaFk?rs=1&pid=ImgDetMain",
    description: "Mint flavor with fluoride protection",
    reviews: [
      { user: "Mike", rating: 5, comment: "works perfectly" }
    ]
  },
];


let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Open auth window
function openAuthWindow(formType) {
  const authWindow = window.open('auth.html', '_blank', 'width=500,height=600');
  authWindow.onload = function() {
    if (formType === 'register') {
      authWindow.toggleAuthForm('register');
    }
  };
}

// Handle login from auth window
window.addEventListener('message', function(event) {
  if (event.data.type === 'login') {
    currentUser = event.data.username;
    localStorage.setItem("currentUser", currentUser);
    document.getElementById("shopping-system").style.display = "block";
    document.getElementById("logout-btn").style.display = "inline";
    loadProducts();
  }
});

function logout() {
  currentUser = null;
  localStorage.removeItem("currentUser");
  location.reload();
}

// Product System
function loadProducts(filter = "all") {
  const filtered = filter === "all" ? products : products.filter(p => p.category === filter);
  displayProducts(filtered);
}

function displayProducts(filteredProducts) {
  const container = document.getElementById("products");
  container.innerHTML = filteredProducts.map(product => `
    <div class="product-card">
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>$${product.price.toFixed(2)}</p>
      <button onclick="addToCart(${product.id})">Add to Cart</button>
      <button onclick="showProductDetails(${product.id})">Details</button>
    </div>
  `).join("");
}

function showProductDetails(id) {
  const product = products.find(p => p.id === id);
  const modal = document.getElementById("product-details");

  modal.innerHTML = `
    <h2>${product.name}</h2>
    <img src="${product.image}" style="max-width:300px">
    <p>${product.description}</p>
    <h3>Reviews</h3>
    ${product.reviews.map(r => `
      <div class="review">
        <strong>${r.user}</strong> (${r.rating}/5):
        <p>${r.comment}</p>
      </div>
    `).join("")}
  `;
  document.getElementById("product-modal").style.display = "block";
}

// Cart System
function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCart();
}

function updateCart() {
  const container = document.getElementById("cart-items");
  container.innerHTML = cart.map(item => `
    <div class="cart-item">
      <span>${item.name}</span>
      <span>$${item.price.toFixed(2)}</span>
    </div>
  `).join("");
}

function checkout() {
  alert(`Total: $${cart.reduce((sum, item) => sum + item.price, 0).toFixed(2)}`+ ' Thank you for purchasing our products!');
  cart = [];
  localStorage.removeItem("cart");
  updateCart();
}

// Utility Functions
function closeModal(id) {
  document.getElementById(id).style.display = "none";
}

function filterProducts(category) {
  loadProducts(category);
}

function searchProducts() {
  const term = document.getElementById("search-input").value.toLowerCase();
  const filtered = products.filter(p => p.name.toLowerCase().includes(term));
  displayProducts(filtered);
}

// Initialize
if (currentUser) {
  document.getElementById("shopping-system").style.display = "block";
  document.getElementById("logout-btn").style.display = "inline";
  loadProducts();
}